public enum TipoBebidas {

    copa,cerveza,refresco;
}
