public interface Constantes {

    double IVA_BEBIDAS = 0.21;
    double IVA_COMIDA = 0.10;
    String CIF = "123123123A";
}
