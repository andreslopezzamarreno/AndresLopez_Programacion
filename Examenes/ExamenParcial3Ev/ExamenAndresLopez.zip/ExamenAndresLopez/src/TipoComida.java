public enum TipoComida {

    menu, racion, bocadillo;
}
