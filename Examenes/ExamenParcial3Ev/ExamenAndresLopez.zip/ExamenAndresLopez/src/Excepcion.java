public class Excepcion extends Exception{

    public Excepcion(String message) {
        super(message);
    }
}
