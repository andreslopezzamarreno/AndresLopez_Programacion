package database;

public interface SchemaDB {
    String URL_SERVER = "127.0.0.1:3306";
    String USER = "root";
    String PASS = "admin";
    String DB_NAME = "empresaexamen";
    String TAB_FAC = "factura";
    String TAB_FIL = "filtrada";
    String COL_ID = "id";
    String COL_COMPANIA = "compania";
    String COL_PAIS = "pais";
    String COL_TELEFONO = "telefono";
    String COL_TOTAL = "total";
}
