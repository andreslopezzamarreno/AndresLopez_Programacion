package Examen;

import java.util.Scanner;

public class Ejercicio2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int numero;

        int combinacion;

        System.out.println("Introducir combinacion : ");
        combinacion = sc.nextInt();

        System.out.println("Prueba la combinacion:");
        for (int i = 0; i < 4; i++) {
            numero = sc.nextInt();

            if (combinacion == numero) {
                System.out.println("caja desbloqueada.");
                break;
            }else {
                System.out.println("lo siento prueba de nuevo");
            }
            System.out.println("Caja bloqueada");
        }
    }
}

